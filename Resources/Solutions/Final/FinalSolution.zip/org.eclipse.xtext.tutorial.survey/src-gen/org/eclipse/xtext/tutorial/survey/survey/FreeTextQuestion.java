/**
 */
package org.eclipse.xtext.tutorial.survey.survey;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Free Text Question</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.xtext.tutorial.survey.survey.SurveyPackage#getFreeTextQuestion()
 * @model
 * @generated
 */
public interface FreeTextQuestion extends Question
{
} // FreeTextQuestion
